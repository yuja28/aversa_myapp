package com.myapp.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
