class ImageConstant {
  static String imgAversawebsitefaviconwhite =
      'assets/images/img_aversawebsitefaviconwhite.png';

  static String imgInfo = 'assets/images/img_info.svg';

  static String img3dfaceright2 = 'assets/images/img_3dfaceright2.png';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgRectangle100x100 = 'assets/images/img_rectangle_100x100.png';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgIconlylightnotification =
      'assets/images/img_iconlylightnotification.svg';

  static String imgSong = 'assets/images/img_song.png';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgPlay = 'assets/images/img_play.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgRectangle = 'assets/images/img_rectangle.png';

  static String imgMicrophone = 'assets/images/img_microphone.svg';

  static String imgRectangle101x100 = 'assets/images/img_rectangle_101x100.png';

  static String imgWaveform = 'assets/images/img_waveform.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
